export default {
  entryPoint: './example/App',
};
