module.exports = {extends: '@react-native'};
