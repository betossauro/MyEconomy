#import <Cocoa/Cocoa.h>

@interface ViewController : NSViewController

@end
