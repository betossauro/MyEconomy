#ifdef RCT_NEW_ARCH_ENABLED
#import <React/RCTViewComponentView.h>
#import <react/renderer/components/rnpicker/EventEmitters.h>
#import <React/RCTConversions.h>

NS_ASSUME_NONNULL_BEGIN

@interface RNCPickerComponentView : RCTViewComponentView


@end

NS_ASSUME_NONNULL_END

#endif
